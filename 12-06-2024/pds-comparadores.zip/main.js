// let a = true
// let b = false
// let c = 5
// let d = 3 

// let not = a != b
// let and = a && b
// let or = a || b 
// let igual = a == b 
// let dif = a !== b 
// let maior = c > d 
// let menor = c < d
// let MeOuIg = c >= d 
// let MaOuIg = c <= d

// console.log(`${a} e ${b} = ${not}`)
// console.log(`${a} e ${b} = ${and}`)
// console.log(`${a} e ${b} = ${or}`)
// console.log(`${a} e ${b} = ${igual}`)
// console.log(`${a} e ${b} = ${dif}`)
// console.log(`${c} e ${d} = ${maior}`)
// console.log(`${c} e ${d} = ${menor}`)
// console.log(`${c} e ${d} = ${MeOuIg}`)
// console.log(`${c} e ${d} = ${MaOuIg}`)

// let idade = 15

// let status = idade >= 18 ? 'Adulto' : 'Menor de idade'

// console.log(status)

var palavra1 = 'alfa'
var palavra2 = 'beto'
var resultado = palavra1 + palavra2

console.log(resultado)










